﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using LinearProgramming;

namespace Modeling
{
    public partial class Form1 : Form
    {
        /*
         * Заполнение таблицы
         */
        public Form1()
        {
            InitializeComponent();

            dataGridViewPerformanceCuttingElements.Rows.Add(9);
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            /*
             *      Чтение данных
             */
            int varsCount = dataGridViewPerformanceCuttingElements.RowCount;
            double[] simplexTable = new double[3 * (varsCount)];
            double[] directionFunction = new double[varsCount];

            for (int i = 1, k = 0; i < 4; i++)
            {
                for (int j = 0; j < varsCount; j++, k++)
                {
                    if (dataGridViewPerformanceCuttingElements.Rows[j].Cells[i].Value.ToString() == "-" || dataGridViewPerformanceCuttingElements.Rows[j].Cells[i].Value.ToString() == "- ")
                    {
                        simplexTable[k] = 0;
                    }
                    else
                    {
                        simplexTable[k] = Convert.ToDouble(dataGridViewPerformanceCuttingElements.Rows[j].Cells[i].Value);
                    }
                }
            }

            for (int i = 0, j = 4; i < varsCount; i++)
            {
                if (i < varsCount)
                {
                    directionFunction[i] = Convert.ToDouble(dataGridViewPerformanceCuttingElements.Rows[i].Cells[j].Value);
                }
                else directionFunction[i] = Convert.ToDouble(dataGridViewPerformanceCuttingElements.Rows[i].Cells[j].Value);
            }

            /*
             *      Приступаем к решению Задачи
             */
            SimplexMethod sm = new SimplexMethod();
            double[][] constraints = new double[simplexTable.Length/directionFunction.Length][];
            for(int i = 0; i < constraints.Length; i++)
            {
                constraints[i] = new double[directionFunction.Length];
                for(int j = 0; j < directionFunction.Length; j++)
                {
                    constraints[i][j] = simplexTable[directionFunction.Length*i+j];
                }
            }
 
            double a1 = double.Parse(textBox_a1.Text);
            double a2 = double.Parse(textBox_a2.Text);
            double a3 = double.Parse(textBox_a3.Text);
            int[] equations = {2,2,2};
            // The right-hand sides of the constraints:
            double[] rhs = { a1, a2, a3 };
            sm.init(directionFunction, constraints, equations, rhs);
            Tuple<double[], double> xAndMin = sm.solveCanonicalToMin(true);

            // Now we can call the Solve method to run the Revised
            // Simplex algorithm:
            double[] x = xAndMin.Item1;

            //Vector y = lp1.GetDualSolution();
            double needSum = 0.0;
            foreach (var item in x)
            {
                needSum += item;
            }
            textBoxNeed.Text = needSum.ToString();
            textBoxWaste.Text = xAndMin.Item2.ToString();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBoxWaste_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBoxNeed_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.InitialDirectory = "E:\\Университет\\3.TРЕТИЙ КУРС\\Системы и методы принятия решений\\Четвертый Курс\\LabsAndGPSS\\Laboratornye_po_Modelirovanie_slozhnykh_sistem_i_sluchaynykh_protsessov\\Lab_2\\bin\\Debug";
            openFileDialog1.Filter = "txt files (*.txt)|*.txt";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                loadFile(openFileDialog1.FileName);
                //Form1_TextField_FilePath.Text = openFileDialog1.FileName;

            }
            else
                MessageBox.Show("Error: Could not read file from disk.");
        }

        List<string> vData = new List<string>();
        void loadFile(string path)
        {
            vData.Clear();
            int n = 0;
            StreamReader streamReader = new StreamReader(path);



            while (!streamReader.EndOfStream)
            {
                vData.Add(streamReader.ReadLine());
            }
            streamReader.Close();

            dataGridViewPerformanceCuttingElements.Rows.Clear();
            dataGridViewPerformanceCuttingElements.Rows.Add(vData.Count / 6);

            for (int i = 0, j = 0; i < vData.Count; i += 6, j++)
            {
                dataGridViewPerformanceCuttingElements.Rows[j].SetValues(vData[i], vData[i + 1], vData[i + 2], vData[i + 3], vData[i + 4]);

            }

            showPolly();
        }
        void showPolly()
        {
            label4.Text = "";
            label5.Text = "";
            label6.Text = "";

            label7.Text = "";
            for (int i = 0, j = 0; i < vData.Count; i += 6, j++)
            {
                label7.Text += vData[i + 4].ToString() + "x" + j;

                if (vData[i + 1] != "-") { label4.Text += vData[i + 1].ToString() + "x" + j; }
                if (vData[i + 2] != "-") { label5.Text += vData[i + 2].ToString() + "x" + j; }
                if (vData[i + 3] != "-") { label6.Text += vData[i + 3].ToString() + "x" + j; }
                                
                    if (i + 6 != vData.Count + 1)
                    {
                        label7.Text += " + ";
                        if (vData[i + 1 + 6] != "-")
                        {
                            label4.Text += " + ";
                        }
                        if (vData[i + 2 + 6] != "-")
                        {
                            label5.Text += " + ";
                        }
                        if (vData[i + 3 + 6] != "-")
                        {
                            label6.Text += " + ";
                        }
                    }
                    else
                    {
                        label7.Text += " -> min";

                        label4.Text += " = " + textBox_a1.Text;
                        label5.Text += " = " + textBox_a2.Text;
                        label6.Text += " = " + textBox_a3.Text;
                    }
            }
            if (label4.Text[0] == ' ')
            {
                label4.Text = label4.Text.Substring(3);
            }
            if (label5.Text[0] == ' ')
            {
                label5.Text = label5.Text.Substring(3);
            }
            if (label6.Text[0] == ' ')
            {
                label6.Text = label6.Text.Substring(3);
            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

    }
}
