﻿namespace Modeling
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.dataGridViewPerformanceCuttingElements = new System.Windows.Forms.DataGridView();
            this.ColumnCaseOfCutting = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnFirstType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSecondType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnThird = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnWasteProducts = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBoxWaste = new System.Windows.Forms.TextBox();
            this.buttonCalculate = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxNeed = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_a1 = new System.Windows.Forms.TextBox();
            this.label_a3 = new System.Windows.Forms.Label();
            this.label_a1 = new System.Windows.Forms.Label();
            this.label_a2 = new System.Windows.Forms.Label();
            this.textBox_a2 = new System.Windows.Forms.TextBox();
            this.textBox_a3 = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPerformanceCuttingElements)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridViewPerformanceCuttingElements
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridViewPerformanceCuttingElements.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewPerformanceCuttingElements.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewPerformanceCuttingElements.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewPerformanceCuttingElements.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.dataGridViewPerformanceCuttingElements.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewPerformanceCuttingElements.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewPerformanceCuttingElements.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewPerformanceCuttingElements.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPerformanceCuttingElements.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnCaseOfCutting,
            this.ColumnFirstType,
            this.ColumnSecondType,
            this.ColumnThird,
            this.ColumnWasteProducts});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewPerformanceCuttingElements.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewPerformanceCuttingElements.GridColor = System.Drawing.Color.DarkGoldenrod;
            this.dataGridViewPerformanceCuttingElements.Location = new System.Drawing.Point(9, 16);
            this.dataGridViewPerformanceCuttingElements.Name = "dataGridViewPerformanceCuttingElements";
            this.dataGridViewPerformanceCuttingElements.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.Yellow;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewPerformanceCuttingElements.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridViewPerformanceCuttingElements.RowsDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewPerformanceCuttingElements.Size = new System.Drawing.Size(567, 226);
            this.dataGridViewPerformanceCuttingElements.TabIndex = 1;
            // 
            // ColumnCaseOfCutting
            // 
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.DarkGreen;
            this.ColumnCaseOfCutting.DefaultCellStyle = dataGridViewCellStyle3;
            this.ColumnCaseOfCutting.HeaderText = "Вариант раскроя";
            this.ColumnCaseOfCutting.Name = "ColumnCaseOfCutting";
            // 
            // ColumnFirstType
            // 
            this.ColumnFirstType.HeaderText = "1-ог вида";
            this.ColumnFirstType.Name = "ColumnFirstType";
            // 
            // ColumnSecondType
            // 
            this.ColumnSecondType.HeaderText = "2-го вида";
            this.ColumnSecondType.Name = "ColumnSecondType";
            // 
            // ColumnThird
            // 
            this.ColumnThird.HeaderText = "3-го вида";
            this.ColumnThird.Name = "ColumnThird";
            // 
            // ColumnWasteProducts
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.Tomato;
            this.ColumnWasteProducts.DefaultCellStyle = dataGridViewCellStyle4;
            this.ColumnWasteProducts.HeaderText = "Отходы, см";
            this.ColumnWasteProducts.Name = "ColumnWasteProducts";
            // 
            // textBoxWaste
            // 
            this.textBoxWaste.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxWaste.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textBoxWaste.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxWaste.ForeColor = System.Drawing.Color.Gold;
            this.textBoxWaste.Location = new System.Drawing.Point(26, 118);
            this.textBoxWaste.Name = "textBoxWaste";
            this.textBoxWaste.ReadOnly = true;
            this.textBoxWaste.Size = new System.Drawing.Size(200, 29);
            this.textBoxWaste.TabIndex = 9;
            this.textBoxWaste.TextChanged += new System.EventHandler(this.textBoxWaste_TextChanged);
            // 
            // buttonCalculate
            // 
            this.buttonCalculate.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCalculate.Location = new System.Drawing.Point(42, 167);
            this.buttonCalculate.Name = "buttonCalculate";
            this.buttonCalculate.Size = new System.Drawing.Size(170, 27);
            this.buttonCalculate.TabIndex = 0;
            this.buttonCalculate.Text = "Вычислить";
            this.buttonCalculate.UseVisualStyleBackColor = true;
            this.buttonCalculate.Click += new System.EventHandler(this.buttonCalculate_Click);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(212, 22);
            this.label2.TabIndex = 10;
            this.label2.Text = "Количество отходов (см):";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(187, 22);
            this.label3.TabIndex = 11;
            this.label3.Text = "Необходимо рулонов:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // textBoxNeed
            // 
            this.textBoxNeed.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxNeed.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textBoxNeed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxNeed.ForeColor = System.Drawing.Color.Gold;
            this.textBoxNeed.Location = new System.Drawing.Point(26, 61);
            this.textBoxNeed.Name = "textBoxNeed";
            this.textBoxNeed.ReadOnly = true;
            this.textBoxNeed.Size = new System.Drawing.Size(200, 29);
            this.textBoxNeed.TabIndex = 8;
            this.textBoxNeed.TextChanged += new System.EventHandler(this.textBoxNeed_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBox_a1);
            this.groupBox1.Controls.Add(this.label_a3);
            this.groupBox1.Controls.Add(this.label_a1);
            this.groupBox1.Controls.Add(this.label_a2);
            this.groupBox1.Controls.Add(this.textBox_a2);
            this.groupBox1.Controls.Add(this.textBox_a3);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox1.ForeColor = System.Drawing.Color.Gold;
            this.groupBox1.Location = new System.Drawing.Point(582, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(267, 172);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "План заготовки";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(8, 141);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 22);
            this.label1.TabIndex = 15;
            this.label1.Text = "Нажмите здесь";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBox_a1
            // 
            this.textBox_a1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_a1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textBox_a1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_a1.ForeColor = System.Drawing.Color.Gold;
            this.textBox_a1.Location = new System.Drawing.Point(202, 41);
            this.textBox_a1.Name = "textBox_a1";
            this.textBox_a1.Size = new System.Drawing.Size(54, 29);
            this.textBox_a1.TabIndex = 12;
            this.textBox_a1.Text = "60";
            // 
            // label_a3
            // 
            this.label_a3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_a3.AutoSize = true;
            this.label_a3.Location = new System.Drawing.Point(146, 112);
            this.label_a3.Name = "label_a3";
            this.label_a3.Size = new System.Drawing.Size(38, 22);
            this.label_a3.TabIndex = 9;
            this.label_a3.Text = "a3 =";
            // 
            // label_a1
            // 
            this.label_a1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_a1.AutoSize = true;
            this.label_a1.Location = new System.Drawing.Point(146, 43);
            this.label_a1.Name = "label_a1";
            this.label_a1.Size = new System.Drawing.Size(38, 22);
            this.label_a1.TabIndex = 10;
            this.label_a1.Text = "a1 =";
            // 
            // label_a2
            // 
            this.label_a2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_a2.AutoSize = true;
            this.label_a2.Location = new System.Drawing.Point(146, 78);
            this.label_a2.Name = "label_a2";
            this.label_a2.Size = new System.Drawing.Size(38, 22);
            this.label_a2.TabIndex = 11;
            this.label_a2.Text = "a2 =";
            // 
            // textBox_a2
            // 
            this.textBox_a2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_a2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textBox_a2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_a2.ForeColor = System.Drawing.Color.Gold;
            this.textBox_a2.Location = new System.Drawing.Point(202, 76);
            this.textBox_a2.Name = "textBox_a2";
            this.textBox_a2.Size = new System.Drawing.Size(54, 29);
            this.textBox_a2.TabIndex = 13;
            this.textBox_a2.Text = "90";
            // 
            // textBox_a3
            // 
            this.textBox_a3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_a3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textBox_a3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_a3.ForeColor = System.Drawing.Color.Gold;
            this.textBox_a3.Location = new System.Drawing.Point(202, 110);
            this.textBox_a3.Name = "textBox_a3";
            this.textBox_a3.Size = new System.Drawing.Size(54, 29);
            this.textBox_a3.TabIndex = 14;
            this.textBox_a3.Text = "320";
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.Image = global::Modeling.Properties.Resources._27_9;
            this.pictureBox1.Location = new System.Drawing.Point(6, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(134, 110);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.textBoxNeed);
            this.groupBox2.Controls.Add(this.textBoxWaste);
            this.groupBox2.Controls.Add(this.buttonCalculate);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold);
            this.groupBox2.ForeColor = System.Drawing.Color.Gold;
            this.groupBox2.Location = new System.Drawing.Point(585, 192);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(267, 210);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Результаты";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 12.25F);
            this.label4.ForeColor = System.Drawing.Color.Gold;
            this.label4.Location = new System.Drawing.Point(12, 347);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(518, 21);
            this.label4.TabIndex = 16;
            this.label4.Text = "Условие 1                                                           \"План заготов" +
    "ки\"";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 12.25F);
            this.label5.ForeColor = System.Drawing.Color.Gold;
            this.label5.Location = new System.Drawing.Point(12, 368);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 21);
            this.label5.TabIndex = 17;
            this.label5.Text = "Условие 2";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 12.25F);
            this.label6.ForeColor = System.Drawing.Color.Gold;
            this.label6.Location = new System.Drawing.Point(12, 389);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 21);
            this.label6.TabIndex = 18;
            this.label6.Text = "Условие 3";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 12.25F);
            this.label7.ForeColor = System.Drawing.Color.Gold;
            this.label7.Location = new System.Drawing.Point(12, 318);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(534, 21);
            this.label7.TabIndex = 19;
            this.label7.Text = "Целевая функция - ожидается выбор файла, нажмите на картинку";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(864, 437);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridViewPerformanceCuttingElements);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Моделирование.";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPerformanceCuttingElements)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewPerformanceCuttingElements;
        private System.Windows.Forms.TextBox textBoxWaste;
        private System.Windows.Forms.Button buttonCalculate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxNeed;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnCaseOfCutting;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnFirstType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSecondType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnThird;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnWasteProducts;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textBox_a1;
        private System.Windows.Forms.Label label_a3;
        private System.Windows.Forms.Label label_a1;
        private System.Windows.Forms.Label label_a2;
        private System.Windows.Forms.TextBox textBox_a2;
        private System.Windows.Forms.TextBox textBox_a3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}

