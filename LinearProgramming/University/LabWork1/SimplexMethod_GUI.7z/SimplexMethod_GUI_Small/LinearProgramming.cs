﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinearProgramming
{
    class xVar
    {
        public int num;
        public bool type;
        public bool is_used;
        public xVar()
        {
            num = 0;
            type = true;
            is_used = true;
        }
    };
    class POINT
    {
        public int x;
        public int y;
    }
    class SimplexMethod
    {
        public static int LESS_THAN = 0;
        public static int GREATER_THAN = 1;
        public static int EQUAL_TO = 2;

        bool isInit = true;
        double[] function;
        double[][] constraints;
        int[] equations;
        double[] rhs;

        double[][] SimplexTable;

        double[][] matrix;	    //Собственно матрица
        double[][] is_matrix;   //Матрица для выражения L(x)
        xVar[] vertX;		    //Номера иксов по вертикали
        xVar[] horzX;		    //Номера иксов по горизонтали
        double[][] chart;		//Таблица
        POINT size;			    //Размер матрицы
        POINT size_small;

        /*
         * returns true if all right, false if something wrong, so look at debug
         */
        public bool init(double[] function, double[][] constraints, int[] equations, double[] rhs)
        {
            this.function = function;
            this.constraints = constraints;
            this.equations = equations;
            this.rhs = rhs;
            int nCols = function.Length + 1;
            int nRows = rhs.Length;

            size = new POINT();
            size.y = nRows + 2;
            size.x = nCols + nRows;
            size_small = new POINT();
            size_small.x = nCols;
            size_small.y = nRows;
            //------Установка-номеров-иксов-----//
            horzX = new xVar[nCols - 1];			//Выделение памяти
            vertX = new xVar[nRows];				//Выделение памяти

            for (int i = 0; i < nCols - 1; i++)
            {
                horzX[i] = new xVar();
                horzX[i].num = i + 1;				//Номер переменной
                horzX[i].type = false;			    //Свободные переменные
                horzX[i].is_used = true;			//Используется
            }

            for (int i = 0; i < nRows; i++)
            {
                vertX[i] = new xVar();
                vertX[i].num = nCols + i;			//Номер переменной
                vertX[i].type = true;				//Базисные переменные
                vertX[i].is_used = true;			//Используется
            }
            //------Установка-номеров-иксов-----//

            matrix = new double[size.y][];
            is_matrix = new double[size.y][];

            for (int i = 0; i < size.y; i++)
            {
                matrix[i] = new double[size.x];
                is_matrix[i] = new double[size.x];
            }

            for (int i = 0; i < size.y; i++)
            {
                for (int j = 0; j < size.x; j++)
                {
                    matrix[i][j] = 0;
                    is_matrix[i][j] = 0;
                }
            }

            int c = 0;

            for (int i = (nCols - 1); i < (nCols + nRows - 1); i++)
            {
                matrix[c][i] = 1;
                is_matrix[c][i] = 1;
                c++;
            }


            if (function.Length == 0)
            {
                System.Diagnostics.Debug.WriteLine("in SimplexMethod -> init(...) function.Length == 0");
                isInit = false;
            }
            if (constraints.Length == 0)
            {
                System.Diagnostics.Debug.WriteLine("in SimplexMethod -> init(...) constraints.Length == 0");
                isInit = false;
            }
            if (constraints.Length != equations.Length)
            {
                System.Diagnostics.Debug.WriteLine("in SimplexMethod -> init(...) constraints.Length != equations.Length");
                isInit = false;
            }
            if (equations.Length != rhs.Length)
            {
                System.Diagnostics.Debug.WriteLine("in SimplexMethod -> init(...) equations.Length != rhs.Length");
                isInit = false;
            }

            return isInit;
        }

        private void printTabel(double[][] SimplexTable)
        {
            Console.WriteLine("Решенная симплекс-таблица:");
            for (int i = 0; i < SimplexTable.Length; i++)
            {
                for (int j = 0; j < SimplexTable[i].Length; j++)
                    Console.Write("{0, 7:N3} ", SimplexTable[i][j]);
                Console.WriteLine();
            }
        }

        private bool solveCanonicalToMin_Init()
        {
            bool EQUAL_EQUATIONS_HERE = true;
            if (isInit)
            {
                foreach (int element in equations)
                {
                    if (!(element == EQUAL_TO))
                    {
                        EQUAL_EQUATIONS_HERE = false;
                    }
                }
                if (EQUAL_EQUATIONS_HERE)
                {
                    // do simplex method
                    SimplexTable = new double[this.constraints.Length + 2][]; //+2 F and M

                    // init Tabel
                    for (int i = 0; i < SimplexTable.Length; i++)
                    {
                        SimplexTable[i] = new double[this.function.Length + 1];
                        for (int j = 0; j < SimplexTable[i].Length; j++)
                        {
                            // Add F and M and data
                            if (i == 0)
                            {// add F
                                if (j != SimplexTable[i].Length - 1)
                                {
                                    SimplexTable[i][j] = this.function[j];
                                }
                                else
                                {
                                    SimplexTable[i][j] = 0;
                                }
                            }
                            if (i != 0 && i != SimplexTable.Length - 1)
                            {// add data
                                if (j != SimplexTable[i].Length - 1)
                                {
                                    SimplexTable[i][j] = constraints[i - 1][j];
                                }
                                else
                                {
                                    SimplexTable[i][j] = rhs[i - 1];
                                }
                            }
                        }
                    }

                    // Real Simplex Method
                    // Can Start
                    return true;
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine("in SimplexMethod -> solveCanonicalToMin() in canonical EQUATIONS must be '='");
                    return false;
                }
            }
            else
            {
                System.Diagnostics.Debug.WriteLine("in SimplexMethod -> solveCanonicalToMin() isInit == false, you have made some mistakes in SimplexMethod -> init(...)");
                return false;
            }
        }
        public Tuple<double[], double> solveCanonicalToMin(bool print = false)
        {
            double min = 0;
            int iterN = 0;

            double[] x = new double[this.function.Length];

            if (solveCanonicalToMin_Init())
            {
                for (int i = 0; i < rhs.Length; i++)
                {
                    for (int j = 0; j < function.Length; j++)
                    {
                        matrix[i][j] = SimplexTable[i + 1][j];
                        is_matrix[i][j] = SimplexTable[i + 1][j];
                    }
                    matrix[i][matrix[i].Length - 1] = SimplexTable[i + 1][SimplexTable[i + 1].Length - 1];
                    is_matrix[i][is_matrix[i].Length - 1] = SimplexTable[i + 1][SimplexTable[i + 1].Length - 1];
                }
                for (int j = 0; j < function.Length; j++)
                {
                    matrix[matrix.Length - 2][j] = SimplexTable[0][j];
                    is_matrix[matrix.Length - 2][j] = SimplexTable[0][j];
                }

                CalculateL_x();
                if (print) { printTabel(matrix); }

                while (realSimplexMethodStep1() == 0)
                {
                    if (print) { printTabel(matrix); }
                    iterN++;
                }

                while (realSimplexMethodStep2() == 0)
                {
                    if (print) { printTabel(matrix); }
                    iterN++;
                }


                for (int i = 0; i < x.Length; i++)
                {
                    x[i] = 0;
                }

                for (int i = 0; i < vertX.Length; i++)
                {
                    x[vertX[i].num - 1] = matrix[i][matrix[i].Length - 1];
                }

                for (int i = 0; i < function.Length; i++)
                {
                    min += function[i] * x[i];
                }

                if (iterN > 0)
                {
                    return new Tuple<double[], double>(x, min);
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine("in SimplexMethod -> solveCanonicalToMin(...) - Cannot find min. I think this function does not have minimum :)");
                    return new Tuple<double[], double>(new double[] { 0 }, 0);
                }
            }
            return new Tuple<double[], double>(new double[] { 0 }, 0);
        }

        private void CalculateL_x()             //Вычислить коэфициэнты L(x)
        {
            for (int i = 0; i < (size.y - 2); i++)
            {
                for (int j = 0; j < (size.x - size.y + 1); j++)
                {
                    is_matrix[size.y - 1][j] -= matrix[i][j];

                }
                is_matrix[size.y - 1][size.x - 1] += matrix[i][size.x - 1];
            }

            for (int i = 0; i < size.x - size.y + 1; i++)
            {
                matrix[size.y - 1][i] = is_matrix[size.y - 1][i];
            }

            matrix[size.y - 1][size.x - 1] = is_matrix[size.y - 1][size.x - 1];
        }
        private int realSimplexMethodStep1()    // Выполнить итерацию - первый этап
        {
            //Возвращаемые значения:
            //1 - решение найдено
            //-1 - решений нет
            //0 - итерация закончилась успешно

            int o_Col = -1;	//Опорный столбик
            int o_Row = -1;	//Опорная строка
            double o_Col_temp = 0;	//Вспомогательная переменная
            double o_Row_temp = -1;	//Вспомогательная переменная

            //Находим опорный столбик
            for (int i = 0; i < (size_small.x - 1); i++)
            {
                if (!horzX[i].is_used) continue;			//Если базовая переменная сверху, пропустить

                if ((matrix[size.y - 1][i] < 0) &&			//Элемент меньше нуля
                    (matrix[size.y - 1][i] < o_Col_temp))	//Элемент меньше o_Col_temp
                {
                    o_Col_temp = matrix[size.y - 1][i];		//o_Col_temp равен текущему элементу
                    o_Col = i;							//Индекс столбика равен счетчику цикла
                }
            }


            if (o_Col == -1) return 1; //Если отрицательных элементов нет, решение найдено

            bool is_positive = false;	//Есть ли положительные значения в опорном столбике

            //---Ищем положительные значения в опорном столбике---
            for (int i = 0; i < size_small.y; i++)
            {
                if (matrix[i][o_Col] > 0)
                {
                    is_positive = true;
                    o_Row_temp = matrix[i][size.x - 1] / matrix[i][o_Col];
                    o_Row = i;
                    break;
                }
            }

            if (!is_positive) return -1;	//Положительных значений нет


            //Находим опорную строчку
            for (int i = 0; i < size_small.y; i++)
            {
                if (matrix[i][o_Col] > 0)
                {
                    is_positive = true;

                    if ((matrix[i][size.x - 1] / matrix[i][o_Col]) < o_Row_temp)
                    {
                        o_Row_temp = (matrix[i][size.x - 1] / matrix[i][o_Col]);
                        o_Row = i;
                    }
                }
            }

            if (o_Row == -1) return -1; //Если положительных элементов нет, решений нет

            //Копируем bi в неиспользуемый более столбец matrix

            for (int i = 0; i < size.y; i++)
            {
                matrix[i][size_small.x - 1] = matrix[i][size.x - 1];
            }

            //Создаем новую таблицу

            double[][] chart = new double[size.y][];

            for (int i = 0; i < size.y; i++)
            {
                chart[i] = new double[size_small.x];
            }

            //Заполняем новую таблицу

            for (int i = 0; i < size.y; i++)
            {
                for (int j = 0; j < size_small.x; j++)
                {
                    if (i == o_Row && j == o_Col)		//Опорный элемент
                    {
                        chart[i][j] = 1 / matrix[o_Row][o_Col];
                        continue;
                    }

                    if (i == o_Row)					//Опорная строка
                    {
                        chart[i][j] = matrix[i][j] / matrix[o_Row][o_Col];
                        continue;
                    }

                    if (j == o_Col)					//Опорный столбик
                    {
                        chart[i][j] = -matrix[i][j] / matrix[o_Row][o_Col];
                        //chart[i][j]=0;
                        continue;
                    }
                    //В остальных случаях вычисляем значение элемента по формуле
                    chart[i][j] = ((matrix[i][j] * matrix[o_Row][o_Col]) - (matrix[i][o_Col] * matrix[o_Row][j])) / matrix[o_Row][o_Col];

                }
            }

            //Копируем chart обратно в matrix
            for (int i = 0; i < size.y; i++)
            {
                for (int j = 0; j < size_small.x; j++)
                {
                    matrix[i][j] = chart[i][j];

                    if (j == size_small.x - 1)
                    {
                        matrix[i][size.x - 1] = chart[i][j];//Копируем bi в последний столбик matrix
                    }
                }
            }

            //Меняем номера переменных

            xVar temp = new xVar();

            temp.num = horzX[o_Col].num;
            temp.is_used = horzX[o_Col].is_used;
            temp.type = horzX[o_Col].type;

            horzX[o_Col].num = vertX[o_Row].num;
            horzX[o_Col].is_used = vertX[o_Row].is_used;
            horzX[o_Col].type = vertX[o_Row].type;

            vertX[o_Row].num = temp.num;
            vertX[o_Row].is_used = temp.is_used;
            vertX[o_Row].type = temp.type;

            //--------?--------//
            if (horzX[o_Col].type == true) horzX[o_Col].is_used = false;
            //--------?--------//

            //Итерация закончилась успешно. Возвращаем 0
            return 0;
        }
        private int realSimplexMethodStep2()    // Выполнить итерацию без L(x) - второй этап (поиск оптимального решения)
        {
            //Возвращаемые значения:
            //1 - решение найдено
            //-1 - решений нет
            //0 - итерация закончилась успешно

            int o_Col = -1;	//Опорный столбик
            int o_Row = -1;	//Опорная строка
            double o_Col_temp = 0;	//Вспомогательная переменная
            double o_Row_temp = -1;	//Вспомогательная переменная

            //Находим опорный столбик
            for (int i = 0; i < (size_small.x - 1); i++)
            {
                if (!horzX[i].is_used) continue;			//Если базовая переменная сверху, пропустить

                if ((matrix[size.y - 2][i] < 0) &&			//Элемент меньше нуля
                    (matrix[size.y - 2][i] < o_Col_temp))	//Элемент меньше o_Col_temp
                {
                    o_Col_temp = matrix[size.y - 2][i];		//o_Col_temp равен текущему элементу
                    o_Col = i;							//Индекс столбика равен счетчику цикла
                }
            }

            if (o_Col == -1) return 1; //Если отрицательных элементов нет, решение найдено

            bool is_positive = false;	//Есть ли положительные значения в опорном столбике

            //---Ищем положительные значения в опорном столбике---
            for (int i = 0; i < size_small.y; i++)
            {
                if (matrix[i][o_Col] > 0)
                {
                    is_positive = true;
                    o_Row_temp = matrix[i][size.x - 1] / matrix[i][o_Col];
                    o_Row = i;
                    break;
                }
            }

            if (!is_positive) return -1;	//Положительных значений нет


            //Находим опорную строчку
            for (int i = 0; i < size_small.y; i++)
            {
                if (matrix[i][o_Col] > 0)
                {
                    is_positive = true;

                    if ((matrix[i][size.x - 1] / matrix[i][o_Col]) < o_Row_temp)
                    {
                        o_Row_temp = (matrix[i][size.x - 1] / matrix[i][o_Col]);
                        o_Row = i;
                    }
                }
            }

            if (o_Row == -1) return -1; //Если положительных элементов нет, решений нет

            //Копируем bi в неиспользуемый более столбец matrix

            for (int i = 0; i < size.y; i++)
            {
                matrix[i][size_small.x - 1] = matrix[i][size.x - 1];
            }

            //Создаем новую таблицу

            double[][] chart = new double[size.y][];

            for (int i = 0; i < size.y; i++)
            {
                chart[i] = new double[size_small.x];
            }

            //Заполняем новую таблицу

            for (int i = 0; i < size.y; i++)
            {
                for (int j = 0; j < size_small.x; j++)
                {
                    if (i == o_Row && j == o_Col)		//Опорный элемент
                    {
                        chart[i][j] = 1 / matrix[o_Row][o_Col];
                        continue;
                    }

                    if (i == o_Row)					//Опорная строка
                    {
                        chart[i][j] = matrix[i][j] / matrix[o_Row][o_Col];
                        continue;
                    }

                    if (j == o_Col)					//Опорный столбик
                    {
                        chart[i][j] = -matrix[i][j] / matrix[o_Row][o_Col];
                        //chart[i][j]=0;
                        continue;
                    }
                    //В остальных случаях вычисляем значение элемента по формуле
                    chart[i][j] = ((matrix[i][j] * matrix[o_Row][o_Col]) - (matrix[i][o_Col] * matrix[o_Row][j])) / matrix[o_Row][o_Col];

                }
            }

            //Копируем chart обратно в matrix
            for (int i = 0; i < size.y; i++)
            {
                for (int j = 0; j < size_small.x; j++)
                {
                    matrix[i][j] = chart[i][j];

                    if (j == size_small.x - 1)
                    {
                        matrix[i][size.x - 1] = chart[i][j];//Копируем bi в последний столбик matrix
                    }
                }
            }

            //Меняем номера переменных

            xVar temp = new xVar();

            temp.num = horzX[o_Col].num;
            temp.is_used = horzX[o_Col].is_used;
            temp.type = horzX[o_Col].type;

            horzX[o_Col].num = vertX[o_Row].num;
            horzX[o_Col].is_used = vertX[o_Row].is_used;
            horzX[o_Col].type = vertX[o_Row].type;

            vertX[o_Row].num = temp.num;
            vertX[o_Row].is_used = temp.is_used;
            vertX[o_Row].type = temp.type;

            //--------?--------//
            //if(horzX[o_Col].type==TRUE) horzX[o_Col].is_used=FALSE;
            //--------?--------//

            //Итерация закончилась успешно. Возвращаем 0
            return 0;

        }

    }
}