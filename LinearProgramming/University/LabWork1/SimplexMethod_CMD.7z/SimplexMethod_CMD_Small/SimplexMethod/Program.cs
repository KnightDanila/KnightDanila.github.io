﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using LinearProgramming;

namespace Optimization
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] minFunction = { 10, 50, 0, 10, 70, 40, 0, 60, 0 };
            double[][] constraints = new double[3][];
            constraints[0] = new double[] { 3, 2, 2, 1, 1, 1, 2, 0, 0 };
            constraints[1] = new double[] { 0, 1, 0, 2, 0, 1, 0, 0, 2 };
            constraints[2] = new double[] { 0, 0, 3, 1, 5, 3, 3, 8, 4 };
            int[] equations = { 2, 2, 2 }; //EQUAL_TO
            // The right-hand sides of the constraints:
            double[] rhs = { 60, 90, 320 };

            SimplexMethod a = new SimplexMethod();
            a.init(minFunction, constraints, equations, rhs);
            Tuple<double[], double> xAndMin = a.solveCanonicalToMin(true);

            Console.WriteLine("x = {0}, min={1}", string.Join(";", xAndMin.Item1), xAndMin.Item2);
            Console.ReadLine();
        }
    }
}
